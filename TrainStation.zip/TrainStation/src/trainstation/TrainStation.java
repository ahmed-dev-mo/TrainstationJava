//Author: Ahmed Mohamed 
//Student ID: 168530891
package trainstation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.Random;
import java.util.Scanner;

public class TrainStation {

    private static int WAITING_ROOM_CAPACITY = 30;
    private static final Passenger[] waitingroom = new Passenger[WAITING_ROOM_CAPACITY];
    private static final PassengerQueue trainqueue = new PassengerQueue();

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String menu;

        do {
            System.out.println("");
            System.out.println("");
            System.out.println(" Menu:");
            System.out.println("");
            System.out.println(" A:  Add a passenger to the train queue");
            System.out.println(" D:  Delete passenger from the train queue");
            System.out.println(" L:  Load data back from the file into the train queue");
            System.out.println(" Q:  Quit");
            System.out.println(" R:  Run the simulation and produce report");
            System.out.println(" S:  Store train queue data into a plain text file");
            System.out.println(" V:  View the train queue");

            System.out.println("");
            System.out.println(" Please enter a letter from the menu: ");

            menu = input.next();

            switch (menu) {

                case "A":
                case "a":
                    add();
                    break;

                case "D":
                case "d":
                    delete();
                    break;

                case "L":
                case "l":
                    load();
                    break;

                case "R":
                case "r":
                    run();
                    break;

                case "S":
                case "s":
                    save();
                    break;

                case "V":
                case "v":
                    view();
                    break;

            }
        } while (!menu.equals("q"));
    }

    private static void add() {

        Scanner input = new Scanner(System.in);
        System.out.printf("Enter the first name of the passenger: ");
        String firstName = input.nextLine();
        System.out.printf("Enter the last name of the passenger: ");
        String surname = input.nextLine();
        Passenger p = new Passenger();
        p.setSecondsInQueue(0);
        p.setName(firstName, surname);
        trainqueue.add(p);
    }

    private static void delete() {
        trainqueue.delete();
    }

    private static void load() {
        File file = null;
        Scanner scanner = null;
        try {
            file = new File("src/trainstation/trainQueuedata.txt");
            scanner = new Scanner(file);
        } catch (Exception e) {
            System.out.println("Unable to open file.");
        }
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] fullName = line.split(" ");
            String fName = fullName[0];
            String lName = fullName[1];
            Passenger new1 = new Passenger();
            new1.setName(fName, lName);
            new1.setSecondsInQueue(0);
            trainqueue.add(new1);
        }

    }

    private static void run() {
        // read passenger from file to passenger array
        File file = null;
        Scanner scanner = null;
        try {
            file = new File("src/trainstation/passengers.dat");
            scanner = new Scanner(file);
        } catch (Exception e) {
            System.out.println("Unable to open file.");
        }
        int i = 0, j = 0;
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] fullName = line.split(" ");
            String fName = fullName[0];
            String lName = fullName[1];
            Passenger temp = new Passenger();
            temp.setName(fName, lName);
            temp.setSecondsInQueue(0);
            waitingroom[i++] = temp;
        }
        Random rand = new Random();

        //while queue not becomes empty
        do {
            int n = rand.nextInt(6) + 1;
            int k = 0;
            while (k < n && j < i) {
                Passenger temp = waitingroom[j++];
                trainqueue.add(temp);
                k++;
            }

            // generate delay
            int delay = rand.nextInt(6) + 1;

            trainqueue.addDelay(delay);

            trainqueue.delete();

            trainqueue.updateReport();
        } while (trainqueue.isEmpty());

        // print the list of passengers
        System.out.println("List of passengers: ");
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter("src/trainstation/report.dat");
        } catch (Exception e) {
            System.out.println("Unable to open file.");
        }

        for (j = 0; j < i; j++) {
            System.out.println(waitingroom[j].getName());
            try {
                fileWriter.write(waitingroom[j].getName() + " ");
            } catch (Exception e) {
                System.out.println("Unable to write file.");
            }
        }
        try {
            fileWriter.write("Max winning time: " + trainqueue.getMaxTime() + " ");
            System.out.println("Max winning time: " + trainqueue.getMaxTime());
            fileWriter.write("Min winning time: " + trainqueue.getMinTime() + " ");
            System.out.println("Min winning time: " + trainqueue.getMinTime());
            fileWriter.write("Max Length : " + trainqueue.getLength() + " ");
            System.out.println("Max Length : " + trainqueue.getLength());
        } catch (Exception e) {
            System.out.println("Unable to write file.");
        }

        try {
            fileWriter.close();
        } catch (Exception e) {
            System.out.println("Unable to open file.");
        }

    }

    private static void save() {
        trainqueue.save();
    }

    private static void view() {
        trainqueue.display();
    }

}
