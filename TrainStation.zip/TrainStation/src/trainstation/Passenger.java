//Author: Ahmed Mohamed 
//Student ID: 168530891
package trainstation;

public class Passenger {

    private String firstName;
    private String surname;
    private int secondsInQueue;
    private int count = 0;

    public String getName() {
        return this.firstName + " " + this.surname;
    }

    public void setName(String fname, String lname) {
        this.firstName = fname;
        this.surname = lname;
    }

    public int getSeconds() {
        return this.secondsInQueue;
    }

    public void setSecondsInQueue(int sec) {
        this.secondsInQueue = sec;
    }

    public void display() {

        System.out.println("Passenger name is: " + this.getName());
    }
}
