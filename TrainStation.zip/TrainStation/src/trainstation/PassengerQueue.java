//Author: Ahmed Mohamed 
//Student ID: 168530891
package trainstation;

import java.io.*;
import java.util.Scanner;

public class PassengerQueue {

    private static int WAITING_ROOM_CAPACITY = 30;
    private static final Passenger[] waitingroom = new Passenger[WAITING_ROOM_CAPACITY];
    private static final PassengerQueue trainqueue = new PassengerQueue();
    private final Passenger[] queueArray = new Passenger[30];
    private int first;
    private int last;
    private int maxStayInQueue;
    private int maxLength = 0;

    private static final int size = 30;
    private int maxTime = 0;
    private int minTime = 10000;

    private Object fileWriter;

    public PassengerQueue() {
        this.first = -1;
        this.last = -1;
    }

    public void add(Passenger waitingRoom) {
        int sizer = 30;
        if ((last + 1) % sizer == first) {
            System.out.println("ERROR!!!! QUEUE IS FULL!!!!");

            return;
        }
        if (first == -1) //If queueArray is initially empty
        {
            first = 0;
        }
        last = (last + 1) % sizer;
        queueArray[last] = waitingRoom;
    }

    public Passenger delete() {
        //if the queueArray is empty
        if (first == -1) {
            System.out.println("Queue is empty");
            return null;
        }

        // when queueArray has only one value
        if (first == last) {
            System.out.println("The deleted value is: " + queueArray[first].getName());
            first = last = -1;
            return null;
        }

        Passenger deletedPassenger = queueArray[first];
        first = (first + 1) % size;
        return deletedPassenger;
    }

    public boolean isEmpty() {
        return first == -1;
    }

    public boolean isFull() {
        return (last + 1) % 30 == first;
    }

    public void display() {
        int i;
        if (first == -1) {
            System.out.println("The Queue is Empty ");
        } else {
            i = first;
            System.out.println(" Circular Queue Elements are :  ");
            if (first <= last) {
                while (i <= last) {
                    queueArray[i++].display();
                }
            } else {
                while (i <= 19) {
                    queueArray[i++].display();
                }
                i = 0;

                while (i <= last) {
                    queueArray[i++].display();
                }
            }
        }
    }

    public int getLength() {
        return this.maxLength;
    }

    public int getMaxStay() {
        return this.maxTime;
    }

    public void addDelay(int delay) {
        int i;
        if (first == -1) {
            System.out.println(" Circular Queue is Empty!!! ");
        } else {
            i = first;
            if (first <= last) {
                while (i <= last) {
                    queueArray[i].setSecondsInQueue(queueArray[i].getSeconds() + delay);
                    i++;
                }
            } else {
                while (i <= 19) {
                    queueArray[i].setSecondsInQueue(queueArray[i].getSeconds() + delay);
                    i++;
                }
                i = 0;

                while (i <= last) {
                    queueArray[i].setSecondsInQueue(queueArray[i].getSeconds() + delay);
                    i++;
                }
            }
        }
    }

    public int getMaxTime() {
        return this.maxTime;
    }

    public int getMinTime() {
        return this.minTime;
    }

    public void updateReport() {
        int i;
        if (first == -1) {
            System.out.println(" Circular Queue is Empty!!! ");
        } else {
            i = first;
            if (first <= last) {
                while (i <= last) {
                    this.maxTime = Math.max(this.maxTime, queueArray[i].getSeconds());
                    this.minTime = Math.min(this.minTime, queueArray[i].getSeconds());
                    i++;
                }
                this.maxLength = Math.max(this.maxLength, (this.last - this.first + 1));
            } else {
                int k = 0;
                while (i <= 19) {
                    this.maxTime = Math.max(this.maxTime, queueArray[i].getSeconds());
                    this.minTime = Math.min(this.minTime, queueArray[i].getSeconds());
                    i++;
                    k++;
                }
                i = 0;

                while (i <= last) {
                    this.maxTime = Math.max(this.maxTime, queueArray[i].getSeconds());
                    this.minTime = Math.min(this.minTime, queueArray[i].getSeconds());
                    i++;
                    k++;
                }

                this.maxLength = Math.max(this.maxLength, k);

            }
        }
    }

    // for storing the queue data to the file
    public void save() {
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter("src/trainstation/trainQueuedata.txt");
        } catch (Exception e) {
            System.out.println("Unable to open file.");
        }
        int i;
        if (first == -1) {
            System.out.println(" Circular Queue is Empty!!! ");
            return;
        } else {
            i = first;
            if (first <= last) {
                while (i <= last) {
                    try {
                        fileWriter.write(queueArray[i++].getName() + " ");
                    } catch (Exception e) {
                        System.out.println("Unable to open file.");
                    }
                }
            } else {
                while (i <= 19) {
                    try {
                        fileWriter.write(queueArray[i++].getName() + " ");
                    } catch (Exception e) {
                        System.out.println("Unable to open file.");
                    }
                }

                i = 0;

                while (i <= last) {
                    try {
                        fileWriter.write(queueArray[i++].getName() + " ");
                    } catch (Exception e) {
                        System.out.println("Unable to open file.");
                    }
                }
            }
        }
        try {
            fileWriter.close();
        } catch (Exception e) {
            System.out.println("Unable to open file.");
        }
    }

}
